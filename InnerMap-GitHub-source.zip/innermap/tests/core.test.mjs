import test from 'node:test';
import assert from 'node:assert/strict';
import * as core from '../dist/lib/core.js';
import {requestCompletion} from '../dist/lib/api.js';

test('accepts compatible HTTPS and loopback only, rejects credential URLs',()=>{
 assert.equal(core.normalizeEndpoint('https://example.com/v1/'),'https://example.com/v1/chat/completions');
 assert.equal(core.normalizeEndpoint('http://localhost:11434/v1'),'http://localhost:11434/v1/chat/completions');
 for(const url of ['http://example.com/v1','javascript:alert(1)','https://user:pass@example.com/v1','https://example.com/v1?key=secret','https://example.com/v1#x']) assert.throws(()=>core.normalizeEndpoint(url));
});
test('exports only allowed fields, never secret or consent, including nested imports',()=>{
 const cleaned=core.cleanState({profile:{nickname:'小林',apiKey:'secret'},answers:{goal:'找方向',evil:'x'},config:{apiKey:'secret',endpoint:'x'},apiKey:'secret',consent:true,assessment:{claims:[{id:'1',title:'标题',observation:'描述',evidence:['依据'],confidence:'待验证',secret:'secret'}]}});
 assert.equal(cleaned.profile.nickname,'小林');
 assert.equal(cleaned.answers.goal,'找方向');
 assert.ok(!JSON.stringify(cleaned).includes('secret'));
 assert.ok(!('config' in cleaned));assert.ok(!('consent' in cleaned));
});
test('selected context excludes family, resume and symbolic data when deselected',()=>{
 const messages=core.buildMessages('profile',{profile:{nickname:'小林',family:'private',resume:'CV_SECRET',mbti:'ENTP',birthDate:'2000-01-01'},answers:{family:'FAMILY_SECRET',goal:'找工作'}},{resume:false,symbolic:false,family:false});
 const s=JSON.stringify(messages);assert.ok(s.includes('找工作'));assert.ok(!s.includes('CV_SECRET'));assert.ok(!s.includes('FAMILY_SECRET'));assert.ok(!s.includes('ENTP'));assert.ok(!s.includes('2000-01-01'));
 assert.match(messages[0].content,/不.*诊断/);assert.match(messages[0].content,/不.*排盘/);
});
test('normalizes fenced JSON and rejects ungrounded malformed profile',()=>{
 assert.equal(core.normalizeProfile('```json\n{"claims":[{"title":"观点","observation":"待验证","evidence":["经历"],"confidence":"有限"}]}\n```').claims.length,1);
 assert.throws(()=>core.normalizeProfile('{"claims":[]}'));
 assert.throws(()=>core.normalizeProfile('not json'));
});
test('report requires actionable horizons and paths, retains evidence without HTML execution',()=>{
 const report=core.normalizeReport({headline:'<script>x</script>',summary:'摘要',dimensions:[{name:'长板',assessment:'描述',evidence:['经历'],uncertainty:'待验证'}],paths:[{name:'测试',why:'原因',cost:'代价',experiment:'行动'},{name:'备选'}],roadmap:['7天','3个月','1年','3年'].map(horizon=>({horizon,goal:'验证',actions:['完成项目'],checkpoint:'反馈'})),principles:['优先长板'],questions:['是否愿意？']});
 assert.equal(report.headline,'<script>x</script>');assert.equal(report.roadmap[0].actions[0],'完成项目');
 assert.throws(()=>core.normalizeReport({summary:'empty'}));
});
test('refuses network without explicit consent and does not send any request',async()=>{
 let calls=0;
 await assert.rejects(requestCompletion({endpoint:'https://example.com/v1',apiKey:'key',model:'x',messages:[],consent:false,fetchImpl:async()=>{calls++;}}));
 assert.equal(calls,0);
});
test('consented request sends exact payload, no cookies, no redirects, parses response',async()=>{
 let sent;
 const messages=[{role:'user',content:'test'}];
 const result=await requestCompletion({endpoint:'https://example.com/v1',apiKey:'key',model:'x',messages,consent:true,fetchImpl:async(url,options)=>{sent={url,options};return new Response(JSON.stringify({choices:[{message:{content:'ok'}}]}),{status:200});}});
 assert.equal(result,'ok');assert.deepEqual(JSON.parse(sent.options.body).messages,messages);assert.equal(sent.options.credentials,'omit');assert.equal(sent.options.redirect,'error');
});
test('does not leak provider error body or key in error message',async()=>{
 await assert.rejects(requestCompletion({endpoint:'https://example.com/v1',apiKey:'SECRET',model:'x',messages:[],consent:true,fetchImpl:async()=>new Response('SECRET',{status:401})}),e=>/401/.test(e.message)&&!e.message.includes('SECRET'));
});
test('consent snapshot remains unchanged when caller edits messages or config',()=>{
 const original={endpoint:'https://example.com/v1',model:'one',messages:[{role:'user',content:'visible'}]};
 const s=core.consentSnapshot(original);original.messages[0].content='unreviewed';original.model='two';
 assert.equal(s.messages[0].content,'visible');assert.equal(s.model,'one');assert.ok(Object.isFrozen(s.messages[0]));
});
test('map rejects incomplete horizons and single path',()=>{
 const d={headline:'test',dimensions:[{name:'ability'}],paths:[{name:'one'}],roadmap:[{horizon:'7天',goal:'try',actions:['do']} ]};
 assert.throws(()=>core.normalizeReport(d));
});
test('async task guard discards older extraction and tasks from prior session',()=>{
 const guard=core.createTaskGuard();const a=guard.begin(),b=guard.begin();assert.equal(guard.current(a),false);assert.equal(guard.current(b),true);guard.reset();assert.equal(guard.current(b),false);
});
